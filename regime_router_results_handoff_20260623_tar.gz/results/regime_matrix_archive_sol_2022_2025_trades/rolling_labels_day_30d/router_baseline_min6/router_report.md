# Rolling Router Baseline

Validation start: **2024-01-01**
Minimum available strategies: **6**
Lookback: **365d**

Dense rows score every eligible daily 30d-forward label. Non-overlap rows
sample every configured horizon so returns are not compounded across
overlapping future windows.

## Dense Scores

| router | rows | avg_forward_return_pct | worst_forward_return_pct | negative_rows | hit_best_rate | avg_regret_pct |
| --- | --- | --- | --- | --- | --- | --- |
| oracle | 701 | 13.8451 | -0.3920 | 2 | 1.0000 | 0.0000 |
| rolling_best_mean | 701 | 2.8311 | -25.3477 | 244 | 0.2225 | 11.0140 |
| rolling_top2_mean_60_40 | 701 | 2.8065 | -14.5736 | 202 | 0.2225 | 11.0386 |
| feature_knn_top2_60_40 | 701 | 2.1410 | -23.9923 | 237 | 0.1655 | 11.7042 |
| equal_weight_available | 701 | 1.7475 | -11.0619 | 208 | 0.1098 | 12.0977 |

## Non-Overlap Scores

| router | periods | final_capital | total_return_pct | max_drawdown_pct | negative_periods | avg_period_return_pct |
| --- | --- | --- | --- | --- | --- | --- |
| oracle | 24 | 191231.8456 | 1812.3185 | 0.0000 | 0 | 13.2771 |
| rolling_top2_mean_60_40 | 24 | 19290.6749 | 92.9067 | -14.5736 | 7 | 2.9790 |
| rolling_best_mean | 24 | 19162.4365 | 91.6244 | -25.3477 | 6 | 3.2032 |
| feature_knn_top2_60_40 | 24 | 18519.4702 | 85.1947 | -14.1840 | 9 | 2.8285 |
| equal_weight_available | 24 | 14995.4544 | 49.9545 | -18.9861 | 8 | 1.8226 |
