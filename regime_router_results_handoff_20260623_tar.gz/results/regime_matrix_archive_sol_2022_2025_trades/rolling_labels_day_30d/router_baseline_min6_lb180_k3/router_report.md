# Rolling Router Baseline

Validation start: **2024-01-01**
Minimum available strategies: **6**
Lookback: **180d**

Dense rows score every eligible daily 30d-forward label. Non-overlap rows
sample every configured horizon so returns are not compounded across
overlapping future windows.

## Dense Scores

| router | rows | avg_forward_return_pct | worst_forward_return_pct | negative_rows | hit_best_rate | avg_regret_pct |
| --- | --- | --- | --- | --- | --- | --- |
| oracle | 701 | 13.8451 | -0.3920 | 2 | 1.0000 | 0.0000 |
| rolling_best_mean | 701 | 2.9127 | -17.3442 | 231 | 0.1740 | 10.9324 |
| feature_knn_top2_60_40 | 701 | 2.6802 | -24.0261 | 238 | 0.1940 | 11.1649 |
| rolling_top2_mean_60_40 | 701 | 2.4809 | -12.2621 | 265 | 0.1740 | 11.3642 |
| equal_weight_available | 701 | 1.7475 | -11.0619 | 208 | 0.1098 | 12.0977 |

## Non-Overlap Scores

| router | periods | final_capital | total_return_pct | max_drawdown_pct | negative_periods | avg_period_return_pct |
| --- | --- | --- | --- | --- | --- | --- |
| oracle | 24 | 191231.8456 | 1812.3185 | 0.0000 | 0 | 13.2771 |
| feature_knn_top2_60_40 | 24 | 24275.3293 | 142.7533 | -6.8403 | 8 | 3.9414 |
| rolling_best_mean | 24 | 21876.1747 | 118.7617 | -8.5033 | 7 | 3.6393 |
| rolling_top2_mean_60_40 | 24 | 18677.6758 | 86.7768 | -5.6222 | 11 | 2.8023 |
| equal_weight_available | 24 | 14995.4544 | 49.9545 | -18.9861 | 8 | 1.8226 |
