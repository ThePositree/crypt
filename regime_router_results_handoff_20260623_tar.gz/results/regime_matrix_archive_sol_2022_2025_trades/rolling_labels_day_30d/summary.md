# Rolling Regime Labels

Rows: **1341**
Step: **day**
Horizon: **30d**
Strategies selected: **6**
Losing oracle rows: **2**
Average margin to second: **7.7574%**

## Selection Counts

| strategy | rows |
| --- | ---: |
| `dssv2_013321_ps_macd_squeeze_recent` | 384 |
| `crypt_ensemble_h1_discovery_nr7_bb_squeeze_h4` | 332 |
| `island_2023_021396_engulfing_bb_trend` | 192 |
| `smac_003335_double_bottom_body_to_range` | 172 |
| `crypt_ensemble_h1_discovery_vwap_reclaim_robust` | 140 |
| `crypt_ensemble_h1_discovery_nr4_vwap_robust` | 121 |
