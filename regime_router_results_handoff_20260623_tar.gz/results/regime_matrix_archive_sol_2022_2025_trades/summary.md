# Archived Strategy Performance Matrix

Strategies: **6**
Buckets: **48**
Total trades: **6740**

Files:

- `strategy_manifest.csv`
- `bucket_metrics.csv`
- `matrix_return_pct.csv`
- `matrix_trade_count.csv`
